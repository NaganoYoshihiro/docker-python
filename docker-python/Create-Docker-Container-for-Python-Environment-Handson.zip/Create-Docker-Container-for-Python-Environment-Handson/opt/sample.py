import math
import sys

def main():
	val = float(sys.argv[1])
	print(math.radians(val))

if __name__ == "__main__":
	main()
